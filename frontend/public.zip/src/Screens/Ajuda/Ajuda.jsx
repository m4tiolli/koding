import Logo1 from '../../Components/Logo1';

function Ajuda(){
    return(
        <div className="flex items-center justify-center h-full w-full" style={{ background: "linear-gradient(108deg, #C6D6FF 0%, #FFFFFF 100%)" }}>
            <div className=''>
                <Logo1/>
            </div>
        </div>
    )
}

export default Ajuda;